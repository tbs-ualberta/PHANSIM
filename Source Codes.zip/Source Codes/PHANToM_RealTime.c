/*==========================================
 * PHANToM_RealTime.c
 * Copyright : Alireza Mohammadi
 *             Ali Jazayeri
 *             Mahdi Tavakoli
 *             ECE Dept., Univ. Alberta, 
 *             Edmonton, Canada
 *             Dec 2010
 * Version : 1.01
 * External Clock Generator Block 
 * For The PHANToM Robot
 *=========================================*/

//Crucial for Sfunction implementation:
#define S_FUNCTION_LEVEL 2
#define S_FUNCTION_NAME  PHANToM_RealTime


//Crucial for Sfunction implementation:
#include "simstruc.h"

//Crucial for using clock() function in C:
#include <time.h>

//The time at which the PHANToM starts working:
real_T  t_0;

static void mdlInitializeSizes(SimStruct *S)
{
    //No block parameters:
    ssSetNumSFcnParams(S, 0); 

    //No continuous and discrete states:
    ssSetNumContStates(S, 0);
    ssSetNumDiscStates(S, 0);

    //No input port:
    if (!ssSetNumInputPorts(S, 0)) return;

    //One ouput port:
    if (!ssSetNumOutputPorts(S, 1)) return;
     ssSetOutputPortWidth(S, 0, 1);
   
    ssSetNumSampleTimes(S, 1);
    ssSetNumRWork(S, 1);
    ssSetNumIWork(S, 0);
    ssSetNumPWork(S, 0);
    ssSetNumModes(S, 0);
    ssSetNumNonsampledZCs(S, 0);
    ssSetOptions(S, 0);
}

#define MDL_INITIALIZE_SAMPLE_TIMES
static void mdlInitializeSampleTimes(SimStruct *S)
{
   ssSetSampleTime(S, 0, CONTINUOUS_SAMPLE_TIME);
   ssSetOffsetTime(S, 0, 0.0);
}

#define MDL_START
static void mdlStart(SimStruct *S)
{
    //Get the time at which the PHANToM starts working:
    t_0 = (real_T)clock()/CLOCKS_PER_SEC;
}

static void mdlOutputs(SimStruct *S, int_T tid)
{
   //Put the system real time at the ouput port: 
   real_T *PHANToM_Time = ssGetOutputPortRealSignal(S, 0);
   
   //Calculate how much time (in seconds) has been 
   //elapsed since the PHANToM has started working:
   *PHANToM_Time = (real_T)clock()/CLOCKS_PER_SEC-t_0;
}

static void mdlTerminate(SimStruct *S)
{
    UNUSED_ARG(S); /* unused input argument */
}

/*
 *  Required S-function trailer:
 *  ----------------------------
 */
#ifdef  MATLAB_MEX_FILE    /* Is this file being compiled as a MEX-file? */
#include "simulink.c"      /* MEX-file interface mechanism */
#else
#include "cg_sfun.h"       /* Code generation registration function */
#endif
