/*==========================================
 * PHANToMSfunc.h
 * Copyright (c) 2010 : 
 *             Alireza Mohammadi
 *             Ali Jazayeri
 *             Mahdi Tavakoli
 *             ECE Dept., Univ. Alberta, 
 *             Edmonton, Canada
 * Version : 1.02
 * Simulink Block Interface For The PHANToM
 * Robot
 *=========================================*/

//PreCompiler Commands:

#ifndef _PHANToMSfunc_
#define _PHANToMSfunc_

/*=========================================
 * Include Crucial Header Files & Libraries
 *=========================================*/

//Crucial for Sfunction implementation:
#define S_FUNCTION_LEVEL 2
#define S_FUNCTION_NAME  PHANToMSfunc

//Crucial for Sfunction implementation:
#include "simstruc.h"

#include <windows.h>
#include <iostream>
#include <fstream>
#include "conio.h"
#include <stdio.h>
#include <string.h>

#include <HD/hd.h>
#include <HD/hdScheduler.h>
#include <HDU/hduError.h>
#include <HDU/hduVector.h>

#include "mex.h" 

#pragma comment (lib,"C://Program Files/MATLAB/R2009a/extern/lib/win32/hd.lib")
#pragma comment (lib,"C://Program Files/MATLAB/R2009a/extern/lib/win32/hl.lib")
#pragma comment (lib,"C://Program Files/MATLAB/R2009a/extern/lib/win32/hlu.lib")
#pragma comment (lib,"C://Program Files/MATLAB/R2009a/extern/lib/win32/hdu.lib")

/*==============================
 * PHANToM Function Declarations
 *==============================*/

//Declare PHANToM scheduler function: 
HDCallbackCode HDCALLBACK PHANToM_Scheduler(void *data);

//Declare PHANToM initializer function:
void  PHANToM_Init(void);

//Declare PHANToM terminator function:
void  PHANToM_Term(void);

//Declare MATLAB PHANToM reader function:
void  Matlab_Reads_PHANToM(mxArray *plhs[]);

//Declare PHANToM writer function:
void  PHANToM_control(struct PHANToM);

/*-----------------------------
 $Global Variable Declarations$
 ------------------------------*/

//maximum length of data buffer for saving final values to MATLAB:
HDSchedulerHandle gCallbackHandle = 0;

HHD hHD1;

struct PHANToM{
            hduVector3Dd pos;
            hduVector3Dd gimbalAngle;
            hduVector3Dd jointAngle;
            hduVector3Dd v;
            hduVector3Dd force;
        } Rob1;
        
float uControl[3];

char *PHANToM_Name;

int   Flag;
/*---------------------
 $Function Definitions$
 ----------------------*/

HDCallbackCode HDCALLBACK PHANToM_Scheduler(void *pUserData)
{
        
        //initialize PHANToM control force:    
		Rob1.force = hduVector3Dd(0,0,0); 
        
        hdBeginFrame(hHD1);
        hdGetDoublev(HD_CURRENT_POSITION, Rob1.pos);
        hdGetDoublev(HD_CURRENT_VELOCITY, Rob1.v);		
        hdGetDoublev(HD_CURRENT_JOINT_ANGLES, Rob1.jointAngle); //Joint angles
        hdGetDoublev(HD_CURRENT_GIMBAL_ANGLES, Rob1.gimbalAngle);
        
        PHANToM_control(Rob1);
        
        hdEndFrame(hHD1);

        return HD_CALLBACK_CONTINUE;
}
/*************************************************************************/

void  PHANToM_Init(void)
{
    mexPrintf(PHANToM_Name);
    mexPrintf("\tStarted\n"); 
    hHD1 = hdInitDevice(PHANToM_Name); 
    gCallbackHandle = hdScheduleAsynchronous(PHANToM_Scheduler, 0, 
         HD_MAX_SCHEDULER_PRIORITY);
	hdEnable(HD_FORCE_OUTPUT);
	hdStartScheduler(); 
}

/*************************************************************************/

void  PHANToM_Term(void)
{
    hdStopScheduler();
	hdUnschedule(gCallbackHandle);
	hdDisableDevice(hHD1);
    mexPrintf(PHANToM_Name);
    mexPrintf("\tStopped\n"); 
}
/*************************************************************************/

void  PHANToM_control(struct PHANToM)
{
        
        float a;
        
        if(!Flag)
            a=1;
        else
            a=1000;
    
        Rob1.force[0] = a*uControl[0];
        Rob1.force[1] = a*uControl[1];
        Rob1.force[2] = a*uControl[2];
        
        if (!Flag){
            hdSetDoublev(HD_CURRENT_FORCE, Rob1.force);
        }
        else{
            hdSetDoublev(HD_CURRENT_JOINT_TORQUE,Rob1.force);
          }
}
#endif