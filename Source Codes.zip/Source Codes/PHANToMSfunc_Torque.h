/*==========================================
 * PHANToMSfunc.h
 * Copyright : Alireza Mohammadi
 *             ECE Dept., Univ. Alberta, 
 *             Edmonton, Canada
 *             Dec 2010
 * Version : 1.00
 * PHANToM_SIMULINK Interface C++ S-function
 *=========================================*/

//PreCompiler Commands:

#ifndef _PHANToMSfunc_Torque_
#define _PHANToMSfunc_Torque_

/*=========================================
 * Include Crucial Header Files & Libraries
 *=========================================*/

//Crucial for Sfunction implementation:
#define S_FUNCTION_LEVEL 2
#define S_FUNCTION_NAME  PHANToMSfunc_Torque

//Crucial for Sfunction implementation:
#include "simstruc.h"

#include <windows.h>
#include <iostream>
#include <fstream>
#include "conio.h"

#include <HD/hd.h>
#include <HD/hdScheduler.h>
#include <HDU/hduError.h>
#include <HDU/hduVector.h>

#include "mex.h" 

#pragma comment (lib,"E:/MATLAB/extern/lib/win32/hd.lib")
#pragma comment (lib,"E:/MATLAB/extern/lib/win32/hl.lib")
#pragma comment (lib,"E:/MATLAB/extern/lib/win32/hlu.lib")
#pragma comment (lib,"E:/MATLAB/extern/lib/win32/hdu.lib")

/*==============================
 * PHANToM Function Declarations
 *==============================*/

//Declare PHANToM scheduler function: 
HDCallbackCode HDCALLBACK PHANToM_Scheduler(void *data);

//Declare PHANToM initializer function:
void  PHANToM_Init(void);

//Declare PHANToM terminator function:
void  PHANToM_Term(void);

//Declare MATLAB PHANToM reader function:
void  Matlab_Reads_PHANToM(mxArray *plhs[]);

//Declare PHANToM writer function:
void  PHANToM_control(struct PHANToM);

/*-----------------------------
 $Global Variable Declarations$
 ------------------------------*/

//maximum length of data buffer for saving final values to MATLAB:
HDSchedulerHandle gCallbackHandle = 0;

HHD hHD1;

struct PHANToM{
            hduVector3Dd pos;
            hduVector3Dd gimbalAngle;
            hduVector3Dd jointAngle;
            hduVector3Dd v;
            hduVector3Dd torque;
        } Rob1;
        
float uControl[3];
/*---------------------
 $Function Definitions$
 ----------------------*/

HDCallbackCode HDCALLBACK PHANToM_Scheduler(void *pUserData)
{
        
        //initialize PHANToM control torque:    
		Rob1.torque = hduVector3Dd(0,0,0); 
        
        hdBeginFrame(hHD1);
        hdGetDoublev(HD_CURRENT_POSITION, Rob1.pos);
        hdGetDoublev(HD_CURRENT_VELOCITY, Rob1.v);		
        hdGetDoublev(HD_CURRENT_JOINT_ANGLES, Rob1.jointAngle); //Joint angles
        hdGetDoublev(HD_CURRENT_GIMBAL_ANGLES, Rob1.gimbalAngle);
        
        PHANToM_control(Rob1);
        
        hdEndFrame(hHD1);

        return HD_CALLBACK_CONTINUE;
}
/*************************************************************************/

void  PHANToM_Init(void)
{
    mexPrintf("PHANToM Started\n"); 
    hHD1 = hdInitDevice("Default PHANToM"); 
    gCallbackHandle = hdScheduleAsynchronous(PHANToM_Scheduler, 0, 
         HD_MAX_SCHEDULER_PRIORITY);
	hdEnable(HD_FORCE_OUTPUT);
	hdStartScheduler(); 
}

/*************************************************************************/

void  PHANToM_Term(void)
{
    hdStopScheduler();
	hdUnschedule(gCallbackHandle);
	hdDisableDevice(hHD1);
    mexPrintf("\nPHANToM Stopped\n");
}
/*************************************************************************/

void  PHANToM_control(struct PHANToM)
{
        Rob1.torque[0] = uControl[0];
        Rob1.torque[1] = uControl[1];
        Rob1.torque[2] = uControl[2];
        
        hdSetDoublev(HD_CURRENT_JOINT_TORQUE, Rob1.torque);
}
#endif