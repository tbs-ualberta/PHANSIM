/*==========================================
 * PHANToMSfunc.h
 * Copyright (c) 2010 : 
 *             Alireza Mohammadi
 *             Ali Jazayeri
 *             Mahdi Tavakoli
 *             ECE Dept., Univ. Alberta, 
 *             Edmonton, Canada
 * Version : 1.02
 * Simulink Block Interface For The PHANToM
 * Robot
 *=========================================*/

#include "PHANToMSfunc.h"


// Function: mdlInitializeSizes ===========================================
static void mdlInitializeSizes(SimStruct *S)
{
    // Name of Phantom
    ssSetNumSFcnParams(S, 2);  /* Number of expected parameters */
    if (ssGetNumSFcnParams(S) != ssGetSFcnParamsCount(S)) {
        return; /* Parameter mismatch will be reported by Simulink */
    }
    
    
    
    const mxArray* temp1 = ssGetSFcnParam(S,0);
    
    PHANToM_Name = mxArrayToString(temp1);
     
    const mxArray* temp2 = ssGetSFcnParam(S,1);
   
    Flag = *mxGetPr(temp2);
    
    // Specify I/O
    if (!ssSetNumInputPorts(S, 1)) return;
    ssSetInputPortWidth(S, 0, 3);
    
    
    
    ssSetInputPortRequiredContiguous(S, 0, false); /*direct input signal access*/
    /*
     * Set direct feedthrough flag (1=yes, 0=no).
     * A port has direct feedthrough if the input is used in either
     * the mdlOutputs or mdlGetTimeOfNextVarHit functions.
     * See matlabroot/simulink/src/sfuntmpl_directfeed.txt.
     */
    ssSetInputPortDirectFeedThrough(S, 0, 0);
    
    
    if (!ssSetNumOutputPorts(S,3)) return;
    ssSetOutputPortWidth(S, 0, 3);
    ssSetOutputPortWidth(S, 1, 3);
    ssSetOutputPortWidth(S, 2, 3);
    
    ssSetNumContStates(S,0);
    ssSetNumDiscStates(S,1);
    
   ssSetNumSampleTimes(S, 1);
   ssSetNumRWork(S, 1);
   ssSetNumIWork(S, 0);
   ssSetNumPWork(S, 0);
   ssSetNumModes(S, 0);
   ssSetNumNonsampledZCs(S, 0);
   ssSetOptions(S, 0);
}

#define MDL_INITIALIZE_CONDITIONS
/* Function: mdlInitializeConditions ======================================
 * Abstract:
 *    If the initial condition parameter (X0) is not an empty matrix,
 *    then use it to set up the initial conditions, otherwise,
 *    set the intial conditions to all 0.0
 */
static void mdlInitializeConditions(SimStruct *S)
{    
    real_T *x0 = ssGetRealDiscStates(S);
    *x0 = 0;
}



// Function: mdlInitializeSampleTimes =========================================
// Abstract:
//   This function is used to specify the sample time(s) for your
//   S-function. You must register the same number of sample times as
//   specified in ssSetNumSampleTimes.
static void mdlInitializeSampleTimes(SimStruct *S)
{
   ssSetSampleTime(S, 0, CONTINUOUS_SAMPLE_TIME);
   ssSetOffsetTime(S, 0, 0.0);
}

// Function: mdlStart =======================================================
// Abstract:
//   This function is called once at start of model execution. If you
//   have states that should be initialized once, this is the place
//   to do it.
#define MDL_START
static void mdlStart(SimStruct *S)
{
    PHANToM_Init();
}

#define MDL_UPDATE  /* Change to #undef to remove function */
#if defined(MDL_UPDATE)
  /* Function: mdlUpdate ======================================================
   * Abstract:
   *    This function is called once for every major integration time step.
   *    Discrete states are typically updated here, but this function is useful
   *    for performing any tasks that should only take place once per
   *    integration step.
   */
  static void mdlUpdate(SimStruct *S, int_T tid)
  {
    
    real_T            *x       = ssGetRealDiscStates(S);
    
    
    InputRealPtrsType  u0 = ssGetInputPortRealSignalPtrs(S,0);
    //InputRealPtrsType  u1 = ssGetInputPortRealSignalPtrs(S,1);
    //InputRealPtrsType  u2 = ssGetInputPortRealSignalPtrs(S,2);
    
    *x = 0;
    
     uControl[0] = *u0[0];
     uControl[1] = *u0[1];
     uControl[2] = *u0[2];
  }
#endif /* MDL_UPDATE */



#define MDL_DERIVATIVES  /* Change to #undef to remove function */
#if defined(MDL_DERIVATIVES)
  /* Function: mdlDerivatives =================================================
   * Abstract:
   *    In this function, you compute the S-function block's derivatives.
   *    The derivatives are placed in the derivative vector, ssGetdX(S).
   */
  static void mdlDerivatives(SimStruct *S)
  {   
  }
#endif /* MDL_DERIVATIVES */

// Function: mdlOutputs =======================================================
// Abstract:
//   In this function, you compute the outputs of your S-function
//   block.
static void mdlOutputs(SimStruct *S, int_T tid)
{
               real_T *yGpos = ssGetOutputPortRealSignal(S, 0);
               real_T *yGang = ssGetOutputPortRealSignal(S, 1);
               real_T *yJang = ssGetOutputPortRealSignal(S, 2);
               //real_T *y3 = ssGetOutputPortRealSignal(S, 3);
               //real_T *y4 = ssGetOutputPortRealSignal(S, 4);
               //real_T *y5 = ssGetOutputPortRealSignal(S, 5);
               
               yGpos[0] = Rob1.pos[0];
               yGpos[1] = Rob1.pos[1];
               yGpos[2] = Rob1.pos[2];
               
			   yGang[0] = Rob1.gimbalAngle[0];
               yGang[1] = Rob1.gimbalAngle[1];
               yGang[2] = Rob1.gimbalAngle[2];

               yJang[0] = Rob1.jointAngle[0];
               yJang[1] = Rob1.jointAngle[1];
               yJang[2] = Rob1.jointAngle[2];
}

// Function: mdlTerminate =====================================================
// Abstract:
//   In this function, you should perform any actions that are necessary
//   at the termination of a simulation.  For example, if memory was
//   allocated in mdlStart, this is the place to free it.
static void mdlTerminate(SimStruct *S)
{
    PHANToM_Term();
}


// Required S-function trailer
#ifdef  MATLAB_MEX_FILE    /* Is this file being compiled as a MEX-file? */
#include "simulink.c"      /* MEX-file interface mechanism */
#else
#include "cg_sfun.h"       /* Code generation registration function */
#endif
