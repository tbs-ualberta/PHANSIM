/*==========================================
 * PHANToMSfunc_Teleoperation.h
 * Copyright (c) 2010 : 
 *             Alireza Mohammadi
 *             Ali Jazayeri
 *             Mahdi Tavakoli
 *             ECE Dept., Univ. Alberta, 
 *             Edmonton, Canada
 * Version : 1.02
 * Simulink Block Interface For The PHANToM
 * Teleoperation System
 *=========================================*/

//PreCompiler Commands:

#ifndef _PHANToMSfunc_Teleoperation_
#define _PHANToMSfunc_Teleoperation_

/*=========================================
 * Include Crucial Header Files & Libraries
 *=========================================*/

//Crucial for Sfunction implementation:
#define S_FUNCTION_LEVEL 2
#define S_FUNCTION_NAME  PHANToMSfunc_Teleoperation

//Crucial for Sfunction implementation:
#include "simstruc.h"

#include <windows.h>
#include <iostream>
#include <fstream>
#include "conio.h"
using namespace std;

//Haptics Toolkit header files:
#include <HD/hd.h>
#include <HD/hdScheduler.h>
#include <HDU/hduError.h>
#include <HDU/hduVector.h>

//C-MEX header file:
#include "mex.h" 

#pragma comment (lib,"C://Program Files/MATLAB/R2009a/extern/lib/win32/hd.lib")
#pragma comment (lib,"C://Program Files/MATLAB/R2009a/extern/lib/win32/hl.lib")
#pragma comment (lib,"C://Program Files/MATLAB/R2009a/extern/lib/win32/hlu.lib")
#pragma comment (lib,"C://Program Files/MATLAB/R2009a/extern/lib/win32/hdu.lib")

/*==============================
 * PHANToM Function Declarations
 *==============================*/

//Declare PHANToM scheduler function: 
HDCallbackCode HDCALLBACK PHANToM_Scheduler(void *data);

//Declare PHANToM initializer function:
void  PHANToM_Init(void);

//Declare PHANToM terminator function:
void  PHANToM_Term(void);

//Declare MATLAB PHANToM reader function:
void  Matlab_Reads_PHANToM(mxArray *plhs[]);

//Declare PHANToM writer function:
void  PHANToM_control(struct PHANToM,float []);

/*-----------------------------
 $Global Variable Declarations$
 ------------------------------*/

//maximum length of data buffer for saving final values to MATLAB:
HDSchedulerHandle gCallbackHandle = 0;

HHD hHD1,hHD2;

struct PHANToM{
            hduVector3Dd pos;
            hduVector3Dd gimbalAngle;
            hduVector3Dd jointAngle;
            hduVector3Dd v;
            hduVector3Dd force;
        } Rob1,Rob2;
        
float u1Control[3];
float u2Control[3];

char *PHANToM_Master;
char *PHANToM_Slave;

int   Flag;

/*---------------------
 $Function Definitions$
 ----------------------*/

HDCallbackCode HDCALLBACK PHANToM_Scheduler(void *pUserData)
{
        
        //initialize PHANToM control force:    
		Rob1.force = hduVector3Dd(0,0,0); 
        Rob2.force = hduVector3Dd(0,0,0);
        
        hdBeginFrame(hHD1);
        hdGetDoublev(HD_CURRENT_POSITION, Rob1.pos);
        hdGetDoublev(HD_CURRENT_VELOCITY, Rob1.v);		
        hdGetDoublev(HD_CURRENT_JOINT_ANGLES, Rob1.jointAngle); //Joint angles
        hdGetDoublev(HD_CURRENT_GIMBAL_ANGLES, Rob1.gimbalAngle);
        
        hdBeginFrame(hHD2);
        hdGetDoublev(HD_CURRENT_POSITION, Rob2.pos);
        hdGetDoublev(HD_CURRENT_VELOCITY, Rob2.v);		
        hdGetDoublev(HD_CURRENT_JOINT_ANGLES, Rob2.jointAngle); //Joint angles
        hdGetDoublev(HD_CURRENT_GIMBAL_ANGLES, Rob2.gimbalAngle);
        
        PHANToM_control(Rob2,u2Control);
        
        hdEndFrame(hHD2);
        
        hdMakeCurrentDevice(hHD1);
        PHANToM_control(Rob1,u1Control);
        
        hdEndFrame(hHD1);
        
        
        return HD_CALLBACK_CONTINUE;
}
/*************************************************************************/

void  PHANToM_Init(void)
{
    
    hHD1 = hdInitDevice(PHANToM_Master); 
    mexPrintf("Master:\t");
    mexPrintf(PHANToM_Master);
    mexPrintf("\t started\n");
	hHD2 = hdInitDevice(PHANToM_Slave); 
    mexPrintf("Slave:\t");
    mexPrintf(PHANToM_Slave);
    mexPrintf("\t started\n");
	gCallbackHandle = hdScheduleAsynchronous(PHANToM_Scheduler, 0, 
            HD_MAX_SCHEDULER_PRIORITY);
	hdEnable(HD_FORCE_OUTPUT);
	hdMakeCurrentDevice(hHD1);
	hdEnable(HD_FORCE_OUTPUT);
	hdStartScheduler();
}

/*************************************************************************/

void  PHANToM_Term(void)
{
    hdStopScheduler();
	hdUnschedule(gCallbackHandle);
	hdDisableDevice(hHD1);
    mexPrintf("Master:\t");
    mexPrintf(PHANToM_Master);
    mexPrintf("\t stopped\n");
	hdDisableDevice(hHD2);
    mexPrintf("Slave:\t");
    mexPrintf(PHANToM_Slave);
    mexPrintf("\t stopped\n");
}
/*************************************************************************/

void  PHANToM_control(struct PHANToM Rob, float uControl[3])
{
        float a;
        
        if(!Flag)
            a = 1;
        else
            a= 1000;
        
        Rob.force[0] = a*uControl[0];
        Rob.force[1] = a*uControl[1];
        Rob.force[2] = a*uControl[2];
        
        
        if (!Flag){
            hdSetDoublev(HD_CURRENT_FORCE, Rob.force);
        }
        else{
            hdSetDoublev(HD_CURRENT_JOINT_TORQUE,Rob.force);
          }
}
#endif