/*==========================================
 * PHANToMSfunc_Teleoperation.cpp
 * Copyright (c) 2010 : 
 *             Alireza Mohammadi
 *             Ali Jazayeri
 *             Mahdi Tavakoli
 *             ECE Dept., Univ. Alberta, 
 *             Edmonton, Canada
 * Version : 1.02
 * Simulink Block Interface For The PHANToM
 * Teleoperation System
 *=========================================*/

// Include the Phantom teleoperation header file:
#include "PHANToMSfunc_Teleoperation.h"


// Function: mdlInitializeSizes ===========================================
// Set up the Phantom teleoperation block:
static void mdlInitializeSizes(SimStruct *S)
{
    //Set up the parameters of the Phantom teleoperation block:
    //Name of the master Phantom, name of the slave Phantom, torque_force
    //flag (flag = 0 -> force input , flag = 1 -> torque input)
    ssSetNumSFcnParams(S, 3);  /* Number of expected parameters */
    if (ssGetNumSFcnParams(S) != ssGetSFcnParamsCount(S)) {
        return; // Parameter mismatch will be reported by Simulink 
    }
    
    
    //Get the Phantom teleoperation block parameters:
    const mxArray* temp1 = ssGetSFcnParam(S,0);
    
    PHANToM_Master = mxArrayToString(temp1);
    
    const mxArray* temp2 = ssGetSFcnParam(S,1);
    
    PHANToM_Slave = mxArrayToString(temp2);
     
    const mxArray* temp3 = ssGetSFcnParam(S,2);
   
    Flag = *mxGetPr(temp3);
    
    
     
   
    
    // Specify Input/Output ports of the 
    // Phantom Teleoperation block:
    if (!ssSetNumInputPorts(S, 2)) return;
    ssSetInputPortWidth(S, 0, 3);
    ssSetInputPortWidth(S, 1, 3);
    //ssSetInputPortWidth(S, 2, 1);
    //ssSetInputPortWidth(S, 3, 1);
    //ssSetInputPortWidth(S, 4, 1);
    //ssSetInputPortWidth(S, 5, 1);
    
    // No direct input signal access:
    ssSetInputPortRequiredContiguous(S, 0, false); 
    
    //No direct feed through:
    ssSetInputPortDirectFeedThrough(S, 0, 0);
    
    
    if (!ssSetNumOutputPorts(S,6)) return;
    ssSetOutputPortWidth(S, 0, 3);
    ssSetOutputPortWidth(S, 1, 3);
    ssSetOutputPortWidth(S, 2, 3);
    ssSetOutputPortWidth(S, 3, 3);
    ssSetOutputPortWidth(S, 4, 3);
    ssSetOutputPortWidth(S, 5, 3);
    
    //Define a virtual state for the Phantom teleoperation block:
    ssSetNumContStates(S,0);
    ssSetNumDiscStates(S,1);
    
   ssSetNumSampleTimes(S, 1);
   ssSetNumRWork(S, 1);
   ssSetNumIWork(S, 0);
   ssSetNumPWork(S, 0);
   ssSetNumModes(S, 0);
   ssSetNumNonsampledZCs(S, 0);
   ssSetOptions(S, 0);
}

#define MDL_INITIALIZE_CONDITIONS
// Function: mdlInitializeConditions ======================================
// Set the virtual state initial value equal to zero.

static void mdlInitializeConditions(SimStruct *S)
{    
    real_T *x0 = ssGetRealDiscStates(S);
    *x0 = 0;
}



// Function: mdlInitializeSampleTimes =====================================

static void mdlInitializeSampleTimes(SimStruct *S)
{
    ssSetSampleTime(S, 0, CONTINUOUS_SAMPLE_TIME);
    ssSetOffsetTime(S, 0, 0.0);
}

// Function: mdlStart =====================================================
// Call the Phantom initialization function once at the start 
// of the model execution. 

#define MDL_START
static void mdlStart(SimStruct *S)
{
    PHANToM_Init();
}

#define MDL_UPDATE  /* Change to #undef to remove function */
#if defined(MDL_UPDATE)
//  Function: mdlUpdate ===================================================
// Keep the virtual state value equal to zero at each time step. Read
// the input port values at each time step.
  
 static void mdlUpdate(SimStruct *S, int_T tid)
  {
    
    real_T            *x       = ssGetRealDiscStates(S);
    
    //Get the input port signals:
    InputRealPtrsType  u0 = ssGetInputPortRealSignalPtrs(S,0);
    InputRealPtrsType  u1 = ssGetInputPortRealSignalPtrs(S,1);
    //InputRealPtrsType  u2 = ssGetInputPortRealSignalPtrs(S,2);
    
    //InputRealPtrsType  u3 = ssGetInputPortRealSignalPtrs(S,3);
    //InputRealPtrsType  u4 = ssGetInputPortRealSignalPtrs(S,4);
    //InputRealPtrsType  u5 = ssGetInputPortRealSignalPtrs(S,5);
    
    *x = 0;
     
     //Set the Phantom input signals equal to the input
     //port signals:
     u1Control[0] = *u0[0];
     u1Control[1] = *u0[1];
     u1Control[2] = *u0[2];
     
     u2Control[0] = *u1[0];
     u2Control[1] = *u1[1];
     u2Control[2] = *u1[2];
  }
#endif /* MDL_UPDATE */



#define MDL_DERIVATIVES  /* Change to #undef to remove function */
#if defined(MDL_DERIVATIVES)
  // Function: mdlDerivatives =================================================
  // Not used in Phantom teleoperation block.
  static void mdlDerivatives(SimStruct *S)
  {   
  }
#endif /* MDL_DERIVATIVES */

// Function: mdlOutputs =======================================================
// Prepare the outputs of the Phantom teleoperation block.
static void mdlOutputs(SimStruct *S, int_T tid)
{
               real_T *y0 = ssGetOutputPortRealSignal(S, 0);
               real_T *y1 = ssGetOutputPortRealSignal(S, 1);
               real_T *y2 = ssGetOutputPortRealSignal(S, 2);
               
               real_T *y3 = ssGetOutputPortRealSignal(S, 3);
               real_T *y4 = ssGetOutputPortRealSignal(S, 4);
               real_T *y5 = ssGetOutputPortRealSignal(S, 5);
               
               y0[0] = Rob1.pos[0];
			   y0[1] = Rob1.pos[1];
			   y0[2] = Rob1.pos[2];

			   y1[0] = Rob1.gimbalAngle[0];
			   y1[1] = Rob1.gimbalAngle[1];
			   y1[2] = Rob1.gimbalAngle[2];

               y2[0] = Rob1.jointAngle[0];
               y2[1] = Rob1.jointAngle[1];
               y2[2] = Rob1.jointAngle[2];
               
               y3[0] = Rob2.pos[0];
			   y3[1] = Rob2.pos[1];
			   y3[2] = Rob2.pos[2];

			   y4[0] = Rob2.gimbalAngle[0];
			   y4[1] = Rob2.gimbalAngle[1];
			   y4[2] = Rob2.gimbalAngle[2];

               y5[0] = Rob2.jointAngle[0];
               y5[1] = Rob2.jointAngle[1];
               y5[2] = Rob2.jointAngle[2]; 
           
}

// Function: mdlTerminate =====================================================
// Call the Phantom termination function at the end of the 
// of the model execution.
static void mdlTerminate(SimStruct *S)
{
    PHANToM_Term();
}


// Required S-function trailer
#ifdef  MATLAB_MEX_FILE    /* Is this file being compiled as a MEX-file? */
#include "simulink.c"      /* MEX-file interface mechanism */
#else
#include "cg_sfun.h"       /* Code generation registration function */
#endif
